# 18650CL
Library to calculate 18650 charge in Arduino environment
